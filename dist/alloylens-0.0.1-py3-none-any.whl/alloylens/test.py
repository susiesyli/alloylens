# sanity check: library imported correctly
def say_hello():
    print("Hello from alloylens!")